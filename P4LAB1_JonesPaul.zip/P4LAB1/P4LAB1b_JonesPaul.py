# Paul Jones
# 7/22/2024
# P4LAB1b
# Turtle Import

import turtle


turtle.shape("turtle")
turtle.color("green")
turtle.pensize(10)

turtle.circle(80,180)
turtle.left(90)
turtle.forward(250)

turtle.left(90)
turtle.forward(100)
turtle.backward(200)
turtle.forward(100)
turtle.right(90)
turtle.forward(120)
turtle.circle(-60,200)
