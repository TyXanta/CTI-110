# Paul Jones
# 7/22/2024
# P4LAB1a
# Turtle Import

import turtle


turtle.shape("turtle")

turtle.forward(50)
turtle.left(90)
turtle.forward(50)
turtle.left(90)
turtle.forward(50)
turtle.left(90)
turtle.forward(50)
turtle.left(90)


turtle.forward(80)
turtle.left(120)
turtle.forward(80)
turtle.left(120)
turtle.forward(80)
turtle.left(120)
